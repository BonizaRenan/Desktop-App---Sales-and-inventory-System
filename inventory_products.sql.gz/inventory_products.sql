-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 17, 2023 at 12:05 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.0.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `inventory_products`
--

-- --------------------------------------------------------

--
-- Table structure for table `exportings`
--

CREATE TABLE `exportings` (
  `Record_ID` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Barcode` varchar(100) NOT NULL,
  `Name` varchar(250) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `Id_No` int(11) NOT NULL,
  `Barcode` varchar(100) DEFAULT NULL,
  `Name` varchar(250) NOT NULL,
  `Category` varchar(250) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Unit_Price` float NOT NULL,
  `Status` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`Id_No`, `Barcode`, `Name`, `Category`, `Quantity`, `Unit_Price`, `Status`) VALUES
(1, '4800888602725', 'Knorr Pork Cube', 'Seasonings', 30, 8, 'Available'),
(2, '4800888602718', 'Knorr Chicken Cube', 'Seasonings', 30, 8, 'Available'),
(3, '4801958390108', 'Crispy Fry Orginal', 'Seasonings', 18, 15.5, 'Available'),
(4, '4901958300107', 'Ajinomoto', 'Seasonings', 20, 3, 'Available'),
(5, '0000008182180', 'Maggi Magic Sarap', 'Seasonings', 50, 5, 'Available'),
(6, '4800361415347', 'Nescafe Original', 'Coffee', 25, 8, 'Available'),
(7, '8998666001719', 'Kopiko Brown', 'Coffee', 25, 8, 'Available'),
(8, '4800016022425', 'Great Taste White', 'Coffee', 20, 8, 'Available'),
(9, '4800016021596', 'Great Taste Choco', 'Coffee', 25, 8, 'Available'),
(10, '4800361393126', 'Nescafe White', 'Coffee', 25, 8, 'Available'),
(11, '0748485700052', '555 Tuna Flakes in Oil', 'Canned goods', 15, 30, 'Available'),
(12, '4800249006636', 'San Marino', 'Canned goods', 15, 36, 'Available'),
(13, '4806504710119', 'Mega Sardines', 'Canned goods', 15, 23, 'Available'),
(14, '4800154013057', 'Unipak Mackerel', 'Canned goods', 15, 29, 'Available'),
(15, '0748485800233', 'Argentina Meat Loaf', 'Canned goods', 15, 30, 'Available'),
(16, '4800818809712', 'Champi Choco', 'Candy', 20, 2, 'Available'),
(17, '4800818810817', 'Frutos Sampaloc', 'Candy', 20, 2, 'Available'),
(18, '4800818809651', 'Monami', 'Candy', 20, 2, 'Available'),
(19, '4800103070506', 'Lipps', 'Candy', 20, 2, 'Available'),
(20, '4800818809880', 'V-fresh', 'Candy', 20, 2, 'Available'),
(21, '4800194104029', 'Potato Fries', 'Snacks', 6, 8, 'Available'),
(22, '4800216120112', 'Clover', 'Snacks', 6, 8, 'Available'),
(23, '4806511010066', 'Corn Bits', 'Snacks', 6, 10, 'Available'),
(24, '4800194152884', 'Oishi Martys', 'Snacks', 6, 8, 'Available'),
(25, '4809010524553', 'Sugo Peanuts', 'Snacks', 6, 10, 'Available'),
(29, '8998866606851', 'Surf Powder', 'Laundry', 12, 7, 'Available'),
(30, '4800488100119', 'Tide Powder', 'Laundry', 12, 16, 'Available'),
(31, '4902430929004', 'Downy', 'Laundry', 12, 7, 'Available'),
(32, '4800047840210', 'Zonrox', 'Laundry', 15, 21, 'Available'),
(33, '4800888208651', 'Breeze Powder', 'Laundry', 12, 16, 'Available'),
(34, '4800092110023', 'Hansel', 'Biscuits', 20, 8, 'Available'),
(35, '4800010075922', 'Presto ', 'Biscuits', 20, 8, 'Available'),
(36, '4800010075526', 'Cream-o', 'Biscuits', 20, 8, 'Available'),
(37, '4809010626332', 'Choco Mucho', 'Biscuits', 20, 8, 'Available'),
(38, '4800092550911', 'Fudgee Bar', 'Biscuits', 20, 8, 'Available'),
(39, '4801981118519', 'Royal', 'Beverages', 24, 12, 'Available'),
(40, '4801981118502', 'Coca-Cola', 'Beverages', 24, 12, 'Available'),
(41, '4807770273674', 'Lucky Me Pancit Canton', 'Noodles', 17, 17, 'Available'),
(42, '4807770270024', 'Lucky Me Chicken', 'Noodles', 15, 15, 'Available'),
(43, '4807770272097', 'Lucky Me Beef', 'Noodles', 15, 15, 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `record_outofstock`
--

CREATE TABLE `record_outofstock` (
  `Record_ID` int(11) NOT NULL,
  `Staff_Name` varchar(250) NOT NULL,
  `Date` date NOT NULL,
  `Time` time NOT NULL,
  `Barcode` bigint(100) NOT NULL,
  `Name` varchar(250) NOT NULL,
  `Quantity` int(20) NOT NULL,
  `Price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `record_outofstock`
--

INSERT INTO `record_outofstock` (`Record_ID`, `Staff_Name`, `Date`, `Time`, `Barcode`, `Name`, `Quantity`, `Price`) VALUES
(1, ' Jancen Naval', '2023-01-14', '10:19:20', 4800818810817, 'Frutos Sampaloc', 0, 0),
(2, ' Jancen Naval', '2023-01-14', '10:23:36', 4800361415347, 'Nescafe Original', 0, 0),
(3, ' Jancen Naval', '2023-01-14', '11:40:10', 4800016022425, 'Great Taste White', 0, 0),
(4, ' Jancen Naval', '2023-01-16', '11:07:10', 4800016022425, 'Great Taste White', 5, 40),
(5, ' Jancen Naval', '2023-01-17', '07:00:21', 4800888602725, 'Knorr Pork Cube', 10, 80),
(6, ' Jancen Naval', '2023-01-17', '07:02:10', 4800888602718, 'Knorr Chicken Cube', 10, 80);

-- --------------------------------------------------------

--
-- Table structure for table `stockin_amount`
--

CREATE TABLE `stockin_amount` (
  `id` int(11) NOT NULL,
  `StockIn_Date` date NOT NULL,
  `Total_Amount` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stockin_amount`
--

INSERT INTO `stockin_amount` (`id`, `StockIn_Date`, `Total_Amount`) VALUES
(1, '2023-01-17', '100');

-- --------------------------------------------------------

--
-- Table structure for table `stockin_product`
--

CREATE TABLE `stockin_product` (
  `Id` int(11) NOT NULL,
  `Staff_Name` varchar(250) NOT NULL,
  `StockIn_Date` date NOT NULL,
  `Time` time NOT NULL,
  `Barcode` varchar(100) NOT NULL,
  `Name` varchar(250) NOT NULL,
  `Category` varchar(250) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stockin_product`
--

INSERT INTO `stockin_product` (`Id`, `Staff_Name`, `StockIn_Date`, `Time`, `Barcode`, `Name`, `Category`, `Quantity`) VALUES
(3, ' Jancen Naval', '2023-01-17', '06:59:10', '4800888602725', 'Knorr Pork Cube', 'Seasonings', 10),
(4, ' Jancen Naval', '2023-01-17', '07:02:57', '4800888602718', 'Knorr Chicken Cube', 'Seasonings', 10);

-- --------------------------------------------------------

--
-- Table structure for table `trashbin_items`
--

CREATE TABLE `trashbin_items` (
  `Id_No` int(11) NOT NULL,
  `Barcode` varchar(100) NOT NULL,
  `Name` varchar(250) NOT NULL,
  `Category` varchar(250) NOT NULL,
  `Quantity` int(11) NOT NULL,
  `Price` float NOT NULL,
  `Status` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trashbin_items`
--

INSERT INTO `trashbin_items` (`Id_No`, `Barcode`, `Name`, `Category`, `Quantity`, `Price`, `Status`) VALUES
(44, '', 'dtrd', 'Grains and cereals', 0, 21, 'Out Of Stock'),
(45, '21313', '', '', 0, 12.12, 'Out of Stock');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `exportings`
--
ALTER TABLE `exportings`
  ADD PRIMARY KEY (`Record_ID`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`Id_No`);

--
-- Indexes for table `record_outofstock`
--
ALTER TABLE `record_outofstock`
  ADD PRIMARY KEY (`Record_ID`);

--
-- Indexes for table `stockin_amount`
--
ALTER TABLE `stockin_amount`
  ADD PRIMARY KEY (`id`),
  ADD KEY `StockIn_Date` (`StockIn_Date`);

--
-- Indexes for table `stockin_product`
--
ALTER TABLE `stockin_product`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `StockIn_Date` (`StockIn_Date`);

--
-- Indexes for table `trashbin_items`
--
ALTER TABLE `trashbin_items`
  ADD PRIMARY KEY (`Id_No`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `exportings`
--
ALTER TABLE `exportings`
  MODIFY `Record_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `Id_No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `record_outofstock`
--
ALTER TABLE `record_outofstock`
  MODIFY `Record_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `stockin_amount`
--
ALTER TABLE `stockin_amount`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `stockin_product`
--
ALTER TABLE `stockin_product`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `trashbin_items`
--
ALTER TABLE `trashbin_items`
  MODIFY `Id_No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `stockin_product`
--
ALTER TABLE `stockin_product`
  ADD CONSTRAINT `stockin_product_ibfk_1` FOREIGN KEY (`StockIn_Date`) REFERENCES `stockin_amount` (`StockIn_Date`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
